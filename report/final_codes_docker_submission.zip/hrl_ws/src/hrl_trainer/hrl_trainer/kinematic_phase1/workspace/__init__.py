"""Workspace expansion curriculum utilities."""

