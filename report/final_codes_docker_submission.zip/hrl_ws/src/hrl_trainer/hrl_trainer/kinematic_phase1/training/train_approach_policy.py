"""Train the Phase 1B approach policy."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from ..eval.eval_approach import evaluate_approach_saved_model
from .callbacks import PeriodicCheckpointCallback, PointCurriculumCallback
from .policy_config import (
    approach_default_config_path,
    deep_merge,
    default_artifact_root,
    load_yaml_file,
    ppo_default_config_path,
    to_algorithm_kwargs,
    to_env_config,
    to_eval_config,
    write_json,
)


def _require_training_dependencies() -> None:
    try:
        import gymnasium  # noqa: F401
        import stable_baselines3  # noqa: F401
    except Exception as exc:
        raise RuntimeError("Approach training requires gymnasium and stable-baselines3 in the active environment.") from exc


def _load_config(explicit_path: str | None) -> dict:
    cfg = deep_merge(load_yaml_file(approach_default_config_path()), load_yaml_file(ppo_default_config_path()))
    if explicit_path:
        cfg = deep_merge(cfg, load_yaml_file(Path(explicit_path)))
    return cfg


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Train the Phase 1B approach policy.")
    parser.add_argument("--config")
    parser.add_argument("--run-id", default="approach_policy")
    parser.add_argument("--artifact-root")
    parser.add_argument("--total-timesteps", type=int)
    parser.add_argument("--seed", type=int)
    parser.add_argument("--resume-from", help="Optional PPO checkpoint/model path to continue training from.")
    return parser


def main() -> None:  # pragma: no cover - CLI integration
    _require_training_dependencies()
    from stable_baselines3 import PPO
    from stable_baselines3.common.callbacks import CallbackList
    from stable_baselines3.common.env_util import make_vec_env
    from stable_baselines3.common.utils import FloatSchedule
    from stable_baselines3.common.vec_env import DummyVecEnv, SubprocVecEnv

    parser = build_arg_parser()
    args = parser.parse_args()
    cfg = _load_config(args.config)
    env_cfg = to_env_config(cfg)
    eval_cfg = to_eval_config(cfg)
    algo_kwargs = to_algorithm_kwargs(cfg, "ppo")
    runtime_cfg = cfg.get("training", {})
    if args.total_timesteps is not None:
        algo_kwargs["total_timesteps"] = args.total_timesteps
    if args.seed is not None:
        algo_kwargs["seed"] = args.seed

    artifact_root = Path(args.artifact_root) if args.artifact_root else default_artifact_root("phase1b_approach", args.run_id)
    artifact_root.mkdir(parents=True, exist_ok=True)
    checkpoints_dir = artifact_root / "checkpoints"

    from ..envs.arm_kinematic_env import ArmKinematicEnv

    def _make_env() -> ArmKinematicEnv:
        return ArmKinematicEnv(config=env_cfg)

    n_envs = int(runtime_cfg.get("n_envs", 1))
    device = str(runtime_cfg.get("device", "auto"))
    vec_env_kind = str(runtime_cfg.get("vec_env", "dummy" if n_envs == 1 else "subproc")).lower()
    vec_env_cls = DummyVecEnv if vec_env_kind == "dummy" else SubprocVecEnv
    vec_env_kwargs = {} if vec_env_cls is DummyVecEnv else {"start_method": str(runtime_cfg.get("start_method", "fork"))}
    vec_env = make_vec_env(_make_env, n_envs=n_envs, seed=algo_kwargs.get("seed"), vec_env_cls=vec_env_cls, vec_env_kwargs=vec_env_kwargs)

    total_timesteps = int(algo_kwargs.get("total_timesteps", 100_000))
    model_kwargs = {k: v for k, v in algo_kwargs.items() if k != "total_timesteps"}
    if args.resume_from:
        model = PPO.load(str(args.resume_from), env=vec_env, device=device)
        model.tensorboard_log = str(artifact_root / "tb")
        if "learning_rate" in model_kwargs:
            learning_rate = float(model_kwargs["learning_rate"])
            model.learning_rate = learning_rate
            model.lr_schedule = FloatSchedule(learning_rate)
            for param_group in model.policy.optimizer.param_groups:
                param_group["lr"] = learning_rate
        print(f"Resuming approach policy from {args.resume_from}")
    else:
        model = PPO("MultiInputPolicy", vec_env, verbose=1, tensorboard_log=str(artifact_root / "tb"), device=device, **model_kwargs)

    callbacks = [PeriodicCheckpointCallback(checkpoints_dir, save_freq=int(runtime_cfg.get("checkpoint_freq", 10_000)))]
    curriculum_summary = None
    if env_cfg.curriculum_config.enabled and env_cfg.curriculum_config.stages:
        curriculum_cb = PointCurriculumCallback(
            success_rate_threshold=env_cfg.curriculum_config.success_rate_threshold,
            window_episodes=env_cfg.curriculum_config.window_episodes,
            min_episodes_per_stage=env_cfg.curriculum_config.min_episodes_per_stage,
            max_stage_index=len(env_cfg.curriculum_config.stages) - 1,
        )
        callbacks.append(curriculum_cb)
    else:
        curriculum_cb = None

    model.learn(total_timesteps=total_timesteps, callback=CallbackList(callbacks), reset_num_timesteps=not bool(args.resume_from))
    if curriculum_cb is not None:
        curriculum_summary = curriculum_cb.summary()

    latest_model = artifact_root / "model_latest"
    model.save(str(latest_model))
    stage_index = int(curriculum_summary["stage_index"]) if curriculum_summary is not None else 0
    eval_summary = evaluate_approach_saved_model(
        algorithm="ppo",
        checkpoint_path=latest_model,
        artifact_root=artifact_root / "approach_eval",
        env_config=env_cfg,
        eval_config=eval_cfg,
        stage_index=stage_index,
    )
    write_json(
        artifact_root / "training_summary.json",
        {
            "policy_type": "approach",
            "algorithm": "ppo",
            "run_id": args.run_id,
            "config": cfg,
            "model_path": str(latest_model),
            "resume_from": str(args.resume_from) if args.resume_from else None,
            "n_envs": n_envs,
            "device": device,
            "curriculum_summary": curriculum_summary,
            "approach_eval_summary": eval_summary,
        },
    )
    print(json.dumps(eval_summary, indent=2))


if __name__ == "__main__":  # pragma: no cover
    main()
